function B = triad13_no_fdbck(t,v)

global stimulus
k = 1; 
b=1; alpha =1;

if t>=stimulus(2) && t<=stimulus(3)
    Sz1= stimulus(1);
else
    Sz1=0;
end
if t>=stimulus(4) && t<=stimulus(5)
    Sz2= stimulus(1);
else
    Sz2=0;
end

x = v(1);
y = v(2);
z1 = v(3);
z2 = v(4);

%Z1
B(3) = b*Sz1./(Sz1+k) - alpha*z1;
%Z2
B(4) = b*Sz2./(Sz2+k) - alpha*z2;

%x no feedback
B(1)= 2*b*z1/(z1+k)+ b*z2/(z2+k)- alpha*x;

%y positive feedback
B(2)= b*z1/(z1+10*k)+ b*z2/(z2+k) - alpha*y;


B=B';