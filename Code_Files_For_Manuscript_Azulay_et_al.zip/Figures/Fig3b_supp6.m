%% Different/Same level
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
load('EnPairsClass.mat')
Triads=zeros(2,15);
EnPairsClass2=EnPairsClass(1:2,:);
EnPairsClass2(EnPairsClass2==5) = 4;
EnPairsClass(1:2,:) = EnPairsClass2;
for i=1:length(EnPairsClass)
   if (EnPairsClass(1,i) == EnPairsClass(2,i))
       Triads(1,EnPairsClass(3,i))=Triads(1,EnPairsClass(3,i)) + 1;
   else
       Triads(2,EnPairsClass(3,i))=Triads(2,EnPairsClass(3,i)) + 1;
   end
end
close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 23)
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 1100 500])
B=bar(Triads',0.7,'BarWidth',1);
set(B(1),'FaceColor',[0.9961,0.3098 ,0.3294],'EdgeColor',[0.9961,0.3098 ,0.3294]);
set(B(2),'FaceColor',[0.1,0.1,0.1],'EdgeColor',[.1 .1 .1]);
xlabel('Triad');
ylabel('Number of homogeneous sets');
legend('Same layer pair','Different layers pair','Location','North');
box off
legend boxoff
set(gca,'Linewidth',2);
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Fig3b.eps
eps2xxx('Fig3b.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');

%% Actual levels
close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
Levels=zeros(10,15);
for i=1:length(EnPairsClass)
    if (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 1)
        Levels(1,EnPairsClass(3,i)) = Levels(1,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 2)
        Levels(2,EnPairsClass(3,i)) = Levels(2,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 3)
        Levels(3,EnPairsClass(3,i)) = Levels(3,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 4 && EnPairsClass(2,i) == 4)
        Levels(4,EnPairsClass(3,i)) = Levels(4,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 2)
        Levels(5,EnPairsClass(3,i)) = Levels(5,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 3)
        Levels(6,EnPairsClass(3,i)) = Levels(6,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 4)
        Levels(7,EnPairsClass(3,i)) = Levels(7,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 3)
        Levels(8,EnPairsClass(3,i)) = Levels(8,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 4)
        Levels(9,EnPairsClass(3,i)) = Levels(9,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 4)
        Levels(10,EnPairsClass(3,i)) = Levels(10,EnPairsClass(3,i)) + 1;
    end
end


    
%% Level of Z's
load('supermat5EnSets.mat')
load('neuronClass.mat')
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 17)
neuronClass=neuronClass(:,1);
neuronClass(neuronClass==5) = 4;
Levels=zeros(10,4,15);
for i=1:length(supermat5)
    if (neuronClass(supermat5(i,1)) == 1 && neuronClass(supermat5(i,2)) == 1)
        Levels(1,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(1,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 2 && neuronClass(supermat5(i,2)) == 2)
        Levels(2,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(2,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 3 && neuronClass(supermat5(i,2)) == 3)
        Levels(3,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(3,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 4 && neuronClass(supermat5(i,2)) == 4)
        Levels(4,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(4,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 1 && neuronClass(supermat5(i,2)) == 2)
        Levels(5,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(5,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 1 && neuronClass(supermat5(i,2)) == 3)
        Levels(6,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(6,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 1 && neuronClass(supermat5(i,2)) == 4)
        Levels(7,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(7,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 2 && neuronClass(supermat5(i,2)) == 3)
        Levels(8,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(8,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 2 && neuronClass(supermat5(i,2)) == 4)
        Levels(9,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(9,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    elseif (neuronClass(supermat5(i,1)) == 3 && neuronClass(supermat5(i,2)) == 4)
        Levels(10,neuronClass(supermat5(i,3)),supermat5(i,4)) = Levels(10,neuronClass(supermat5(i,3)),supermat5(i,4)) + 1;
    end
end
close all;


 
 %%
 close all;
 set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
 Levels2=zeros(15,6);
 for i=1:15
 Levels2(i,1)=Levels(1,2,i)+Levels(1,3,i) + Levels(1,4,i) + Levels(2,3,i)...
      + Levels(2,4,i) + Levels(3,4,i) + Levels(5,3,i) + Levels(5,4,i) + Levels(6,4,i) ...
      + Levels(8,4,i);
 Levels2(i,2)= Levels(5,2,i) + Levels(6,3,i) + Levels(7,4,i) + Levels(8,3,i) + Levels(9,4,i) + Levels(10,4,i);
 Levels2(i,3)= Levels(1,1,i) + Levels(2,2,i) + Levels(3,3,i) + Levels(4,4,i);
 Levels2(i,4)=Levels(6,2,i)+Levels(7,3,i) + Levels(7,2,i) + Levels(9,3,i);
 Levels2(i,5)= Levels(5,1,i) + Levels(6,1,i) + Levels(7,1,i) +Levels(8,2,i) +Levels(9,2,i)+Levels(10,3,i) ;
 Levels2(i,6)=Levels(4,1,i)+Levels(4,2,i) + Levels(4,3,i) + Levels(3,1,i)...
      + Levels(3,2,i) + Levels(2,1,i) + Levels(8,1,i) + Levels(9,1,i) + Levels(10,1,i) ...
      + Levels(10,2,i);
 end
 figure('Position',[100 100 1100 400])

 bar(Levels2,'DisplayName','Levels2([1:2,10,13],:)')
 legend({'Both Upstream','Upstream and same level','Both same level','Both different level','Downstream and same level','Both Downstream'},'Location','north')
xlabels  =  {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'};
ylabel('Number of Z neurons');
xlabel('Set type');
box off

legend boxoff
set(gca,'Linewidth',2);
set(gca, 'Xtick', 1:15, 'XtickLabel', xlabels)
 set(gcf, 'PaperPositionMode', 'auto');
 print -depsc2 Figsupp6.eps
 eps2xxx('Figsupp6.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');