load('NumOfEnPUC.mat')
NumOfEnPUC=NumOfEnP;
load('NumOfEnP.mat')
load('EnTriadsP.mat')
load('SuperRandListUC.mat')
load('SuperRandList.mat')
load('SetRandList5PLUS.mat')


%% Fig2d
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 18)
PercentOfEn=zeros(1,1501);
PercentOfEnUC=zeros(1,1501);
Avg=zeros(1,2);
Std=zeros(1,2);
for i=1:length(SuperRandList(1:1001));
    PercentOfEn(i)=(NumOfEnP(i)/length(SuperRandList{i})) * 100;
    PercentOfEnUC(i)=(NumOfEnPUC(i)/length(SuperRandListUC{i})) * 100;

end

for z=1
Avg(z)=mean([NumOfEnP(z,1:1000)]);
Std(z)=std([NumOfEnP(z,1:1000)]);
AvgUC(z)=mean([NumOfEnPUC(z,1:1000)]);
StdUC(z)=std([NumOfEnPUC(z,1:1000)]);
end

close all;
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 440 320])
B=barwitherr([zeros(1), Std(1);zeros(1), StdUC],[NumOfEnP(1,1001)', Avg(1); NumOfEnPUC(1,1001)', AvgUC],0.7,'LineWidth',0.1,'BarWidth',1);
set(B(1),'FaceColor',[0.9961,0.3098 ,0.3294],'EdgeColor',[0.9961,0.3098 ,0.3294])
set(B(2),'FaceColor',[0.4824,0.4863,0.5020],'EdgeColor',[0.4824,0.4863,0.5020])
box off
Avg2=[Avg(1) AvgUC];
Std2=[Std(1) StdUC];
realvals=[NumOfEnP(1,1001)' NumOfEnPUC(1,1001)'];
xlabels  =  {'Connected','Unconnected'};
set(gca, 'Xtick', 1:2, 'XtickLabel', xlabels)
ylabel('Number of homogeneous sets');
legend(['\itC. elegans'],['Shuffled'],'Location','Northwest');
legend boxoff
ylim([0 800]);
set(gca,'Linewidth',2);
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Fig2d.eps
eps2xxx('Fig2d.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
PVALUES=normcdf(-abs((realvals - Avg2) ./ Std2),0,1);

%% FigBreal
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 14)
PercentEnTriads=zeros(1001,15);
for i=1:length(EnTriadsP(1:1001))
    PercentEnTriads(i,1:2) = (EnTriadsP(i,1:2) ./ (sum(EnTriadsP(i,1:2)))) * 100;
end


%% FigBrand
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
Std=std(PercentEnTriads);
Avg=mean(EnTriadsP(1:1000,:,1:2));
Std=std(EnTriadsP(1:1000,:,1:2));

close all;
    
    
 %% Fig2e
 close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 18)
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 830 342])
errorbar(Avg(:,:,1),Std(:,:,1),'o','MarkerSize', 10,'MarkerEdgeColor' , [0.4824,0.4863,0.5020],'MarkerFaceColor' , [0.4824,0.4863,0.5020],'Color' , [0.4824,0.4863,0.5020],'Linewidth',2);
set(gca,'Linewidth',2);
hold all
plot(EnTriadsP(1001,:,1),'o','MarkerSize', 10,'MarkerEdgeColor' , [0.9961,0.3098 ,0.3294],'MarkerFaceColor' , [0.9961,0.3098 ,0.3294]);
    xlabels  =  {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'};
    ylim([0 47]);
    box off
    
    set(gca, 'Xtick', 1:15, 'XtickLabel', xlabels)
    xlabel('Triad');
    ylabel('Number of homogeneous sets');
    
    legend('Shuffled','\itC. elegans','Location','Northwest');
    set(gcf, 'PaperPositionMode', 'auto');
    print -depsc2 Fig2e.eps
    eps2xxx('Fig2e.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
    PVALUES=normcdf(-abs((EnTriadsP(1001,:,1) - Avg(:,:,1)) ./ Std(:,:,1)),0,1);

 %% Fig supp 3
 close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 18)
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 830 342])
errorbar(Avg(:,:,2),Std(:,:,2),'o','MarkerSize', 10,'MarkerEdgeColor' , [0.4824,0.4863,0.5020],'MarkerFaceColor' , [0.4824,0.4863,0.5020],'Color' , [0.4824,0.4863,0.5020],'Linewidth',2);
hold all
plot(EnTriadsP(1001,:,2),'o','MarkerSize', 10,'MarkerEdgeColor' , [0.9961,0.3098 ,0.3294],'MarkerFaceColor' , [0.9961,0.3098 ,0.3294],'LineWidth',2);
    xlabels  =  {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'};
    ylim([0 25]);
    set(gca, 'Xtick', 1:15, 'XtickLabel', xlabels)
    xlabel('Triad');
    ylabel('Number of homogeneous sets');
    legend('Shuffled','\itC. elegans','Location','Northwest');
box off
    title('\bfHGT p-value: 0.005');
    set(gca,'Linewidth',2);

    set(gcf, 'PaperPositionMode', 'auto');
    
    print -depsc2 Figsupp3.eps
    eps2xxx('Figsupp3.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
