function B = triad10_pstv_fdbck(t,v)

global stimulus

k = 1; b=1; alpha =1;

if t>=stimulus(2) && t<=stimulus(3)
    Sx= stimulus(1);
else
    Sx=0;
end

x = v(1);
y = v(2);
z1 = v(3);
z2 = v(4);

%x positive feedback
B(1)= Sx + b*y/(y+k)- alpha*x;

%y positive feedback
B(2)= b*x/(x+k) - alpha*y;

%Z1
B(3) = 1.3*b.*(x/(x+k))+ 1.3*b.*(y/(y+k))- alpha*z1;
%Z2
B(4) = b.*(x/(x+k))+ b.*(y/(y+k))- alpha*z2;

B=B';