function run_triad13(v, stimulus)

%use for example:
%  run_triad13([0,0,0,0],[0.8, 4, 5, 6, 7])
% first vector is the v vector for initial values.
% 2nd bracket vector is [Sx, sz1(t_initiation, t_end), sz2(t_initiation, t_end)]

global stimulus
tspan = 15;
ymax = 1;
leg = {'x','y','z1','z2'};
% [t,B]=ode23s('triad13_pstv_fdbck',tspan,v);
[t,B]=ode23s('triad13_no_fdbck',tspan,v);

% figure(1),
% plot(t, B),
% legend(leg)
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 350 350])
subplot(3,1,2)
plot(t, B(:,3), 'k','LineWidth',2)
hold on
plot(t, B(:,4), 'k','LineWidth',2)
box off
set(gca,'LineWidth',2);
ylabel('Z(t)')
axis([0 tspan 0 0.4])

subplot(3,1,3)
plot(t, B(:,1),'color',[0.4863,0.7333,1],'LineWidth',2),
hold on
plot(t, B(:,2),'color',[0.9961,0.3098 ,0.3294],'LineWidth',2),
hold on
box off
set(gca,'LineWidth',2);
ylabel('X(t) and Y(t)')
xlabel('Time')
axis([0 tspan 0 0.3])

% subplot(4,1,4)
% plot(t, B(:,2),'r'),
% ylabel('Y')
% xlabel('Time')
% axis([0 tspan 0 ymax/2])

sz1=zeros(1,length(t));
for i=1:length(t),
    if t(i)>=stimulus(2) && t(i)<= stimulus(3)
        sz1(i) = stimulus(1);
    end
end
sz2=zeros(1,length(t));
for i=1:length(t),
    if t(i)>=stimulus(4) && t(i)<= stimulus(5)
        sz2(i) = stimulus(1);
    end
end

subplot(3,1,1)
plot(t, sz1,'k', t,sz2, 'k','LineWidth',2)
ylabel('Input(t)')
box off
set(gca,'LineWidth',2);
axis([0 tspan 0 ymax])
    set(gcf, 'PaperPositionMode', 'auto');
    print -depsc2 13NOFeedBack.eps
    eps2xxx('13NOFeedBack.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');