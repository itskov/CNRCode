function run_triad10(v, stimulus)
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
%use for example:
%  run_triad10([0,0,0,0],[0.8, 4, 6])
% first vector is the v vector for initial values.
% 2nd bracket vector is [Sx, t_initiation, t_end]
addpath('..');
global stimulus
tspan = 20;
ymax = 1;
leg = {'x','y','z1','z2'};
% [t,B]=ode23s('triad10_pstv_fdbck',tspan,v);
[t,B]=ode23s('triad10_no_fdbck',tspan,v);
% 
% figure(1),
% plot(t, B,'.-','LineWidth',2),
% legend(leg)
% box off
% set(gca,'LineWidth',2);
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 350 350])

% figure(2)
subplot(4,1,2)
plot(t, B(:,1),'k','LineWidth',2)
ylabel('X(t)')
axis([0 tspan 0 ymax])
box off
set(gca,'LineWidth',2);

subplot(4,1,3)
plot(t, B(:,2),'k','LineWidth',2),
ylabel('Y(t)')
axis([0 tspan -0.1 ymax])
box off
set(gca,'LineWidth',2);
subplot(4,1,4)
plot(t, B(:,3),'color',[0.4863,0.7333,1],'LineWidth',2),
box off
set(gca,'LineWidth',2);
hold on
plot(t, B(:,4),'color',[0.9961,0.3098 ,0.3294],'LineWidth',2),
plot(0:0.5:tspan, 0.5,'k.-')
box off
set(gca,'LineWidth',2);
ylabel('Z(t)')
xlabel('Time')
axis([0 tspan 0 ymax])

s=zeros(1,length(t));
for i=1:length(t),
    if t(i)>=stimulus(2) && t(i)<= stimulus(3)
        s(i) = stimulus(1);
    end
end
subplot(4,1,1)
plot(t, s,'k','LineWidth',2)
ylabel('Sx(t)')
axis([0 tspan 0 ymax])
box off
set(gca,'LineWidth',2);
    set(gcf, 'PaperPositionMode', 'auto');
    print -depsc2 10NOFeedBack.eps
    eps2xxx('10NOFeedBack.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');