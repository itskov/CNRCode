clear all
load('SuperRandList.mat')
load('Pairs.mat')
load('EnPairsClass.mat')
load('neuronClass.mat')
load('EnPairs.mat')
EnPairs=EnPairs(1:2,:);
neuronClass=neuronClass(:,1);
neuronClass(neuronClass==5) = 4;
Triads=zeros(2,15);
EnPairsClass2=EnPairsClass(1:2,:);
EnPairsClass2(EnPairsClass2==5) = 4;
EnPairsClass(1:2,:) = EnPairsClass2;
for i=1:length(EnPairsClass)
   if (EnPairsClass(1,i) == EnPairsClass(2,i))
       Triads(1,EnPairsClass(3,i))=Triads(1,EnPairsClass(3,i)) + 1;
   else
       Triads(2,EnPairsClass(3,i))=Triads(2,EnPairsClass(3,i)) + 1;
   end
end
RealSets=SuperRandList(1001);
Levels=zeros(16,15);
for i=1:length(EnPairsClass)
    if (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 1)
        Levels(1,EnPairsClass(3,i)) = Levels(1,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 2)
        Levels(2,EnPairsClass(3,i)) = Levels(2,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 3)
        Levels(3,EnPairsClass(3,i)) = Levels(3,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 4 && EnPairsClass(2,i) == 4)
        Levels(4,EnPairsClass(3,i)) = Levels(4,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 2)
        Levels(5,EnPairsClass(3,i)) = Levels(5,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 3)
        Levels(6,EnPairsClass(3,i)) = Levels(6,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 1 && EnPairsClass(2,i) == 4)
        Levels(7,EnPairsClass(3,i)) = Levels(7,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 3)
        Levels(8,EnPairsClass(3,i)) = Levels(8,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 4)
        Levels(9,EnPairsClass(3,i)) = Levels(9,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 4)
        Levels(10,EnPairsClass(3,i)) = Levels(10,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 2 && EnPairsClass(2,i) == 1)
        Levels(11,EnPairsClass(3,i)) = Levels(11,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 2)
        Levels(12,EnPairsClass(3,i)) = Levels(12,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 3 && EnPairsClass(2,i) == 1)
        Levels(13,EnPairsClass(3,i)) = Levels(13,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 4 && EnPairsClass(2,i) == 3)
        Levels(14,EnPairsClass(3,i)) = Levels(14,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 4 && EnPairsClass(2,i) == 2)
        Levels(15,EnPairsClass(3,i)) = Levels(15,EnPairsClass(3,i)) + 1;
    elseif (EnPairsClass(1,i) == 4 && EnPairsClass(2,i) == 1)
        Levels(16,EnPairsClass(3,i)) = Levels(16,EnPairsClass(3,i)) + 1;
    end
end


%HGT
N=length(RealSets{:});
n(1:15)=sum(Triads,1);
K=zeros(1,16);
for setn=1:length(Pairs)
if (neuronClass(Pairs(1,setn)) == 1 && neuronClass(Pairs(2,setn)) == 1)
   K(1)=K(1)+1;
elseif (neuronClass(Pairs(1,setn)) == 2 && neuronClass(Pairs(2,setn)) == 2)
   K(2)=K(2)+1;   
elseif (neuronClass(Pairs(1,setn)) == 3 && neuronClass(Pairs(2,setn)) == 3)
   K(3)=K(3)+1;   
elseif (neuronClass(Pairs(1,setn)) == 4 && neuronClass(Pairs(2,setn)) == 4)
   K(4)=K(4)+1;   
elseif ((neuronClass(Pairs(1,setn)) == 1 && neuronClass(Pairs(2,setn)) == 2))
   K(5)=K(5)+1;   
elseif (neuronClass(Pairs(1,setn)) == 1 && neuronClass(Pairs(2,setn)) == 3)
   K(6)=K(6)+1;   
elseif (neuronClass(Pairs(1,setn)) == 1 && neuronClass(Pairs(2,setn)) == 4)
   K(7)=K(7)+1;   
elseif (neuronClass(Pairs(1,setn)) == 2 && neuronClass(Pairs(2,setn)) == 3)
   K(8)=K(8)+1;   
elseif (neuronClass(Pairs(1,setn)) == 2 && neuronClass(Pairs(2,setn)) == 4)
   K(9)=K(9)+1;   
elseif (neuronClass(Pairs(1,setn)) == 3 && neuronClass(Pairs(2,setn)) == 4)
   K(10)=K(10)+1;   
elseif ((neuronClass(Pairs(1,setn)) == 2 && neuronClass(Pairs(2,setn)) == 1))
   K(11)=K(11)+1;   
elseif (neuronClass(Pairs(1,setn)) == 3 && neuronClass(Pairs(2,setn)) == 2)
   K(12)=K(12)+1;   
elseif (neuronClass(Pairs(1,setn)) == 3 && neuronClass(Pairs(2,setn)) == 1)
   K(13)=K(13)+1;   
elseif (neuronClass(Pairs(1,setn)) == 4 && neuronClass(Pairs(2,setn)) == 3)
   K(14)=K(14)+1;   
elseif (neuronClass(Pairs(1,setn)) == 4 && neuronClass(Pairs(2,setn)) == 2)
   K(15)=K(15)+1;   
elseif (neuronClass(Pairs(1,setn)) == 4 && neuronClass(Pairs(2,setn)) == 1)
   K(16)=K(16)+1;   
end
end

k=zeros(1,16);
for setn=1:length(EnPairs)
if (neuronClass(EnPairs(1,setn)) == 1 && neuronClass(EnPairs(2,setn)) == 1)
   k(1)=k(1)+1;
elseif (neuronClass(EnPairs(1,setn)) == 2 && neuronClass(EnPairs(2,setn)) == 2)
   k(2)=k(2)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 3 && neuronClass(EnPairs(2,setn)) == 3)
   k(3)=k(3)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 4 && neuronClass(EnPairs(2,setn)) == 4)
   k(4)=k(4)+1;   
elseif ((neuronClass(EnPairs(1,setn)) == 1 && neuronClass(EnPairs(2,setn)) == 2))
   k(5)=k(5)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 1 && neuronClass(EnPairs(2,setn)) == 3)
   k(6)=k(6)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 1 && neuronClass(EnPairs(2,setn)) == 4)
   k(7)=k(7)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 2 && neuronClass(EnPairs(2,setn)) == 3)
   k(8)=k(8)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 2 && neuronClass(EnPairs(2,setn)) == 4)
   k(9)=k(9)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 3 && neuronClass(EnPairs(2,setn)) == 4)
   k(10)=k(10)+1;   
elseif ((neuronClass(EnPairs(1,setn)) == 2 && neuronClass(EnPairs(2,setn)) == 1))
   k(11)=k(11)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 3 && neuronClass(EnPairs(2,setn)) == 2)
   k(12)=k(12)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 3 && neuronClass(EnPairs(2,setn)) == 1)
   k(13)=k(13)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 4 && neuronClass(EnPairs(2,setn)) == 3)
   k(14)=k(14)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 4 && neuronClass(EnPairs(2,setn)) == 2)
   k(15)=k(15)+1;   
elseif (neuronClass(EnPairs(1,setn)) == 4 && neuronClass(EnPairs(2,setn)) == 1)
   k(16)=k(16)+1;   
end
end
k=Levels;
pvalueA=ones(15,16);
pvalueAll=ones(15,16);
for i=1:length(n)
        for j=1:size(k,1)
            if(n(i)>5)
         pvalueA(i,j)=1-hygecdf(k(j,i),N,K(j),n(i));
            end
         if (pvalueA(i,j)<(0.05 / (16*15)) && k(j,i)>=5 && n(i)~=0)
             disp(['Set homogeneous with Triad ', num2str(i), ' is located in layer ', num2str(j), ' With pvalue ', num2str((pvalueA(i,j)*(16*15)))]);
             
         end
        end
end
pvalueAll=pvalueA;
pvalueA(pvalueA<(0.05/(16*15))) = 0;
pvalueA(pvalueA>=(0.05/(16*15))) = 1;

%% fig
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 20)

%% NewFig
close all;
figure('Position',[100 100 600 400])
pvalueAll(pvalueAll==0) = 10e-15;
semilogy(pvalueAll(:),'.','Markersize',24,'color',[0.5,0.5,0.5])
hold on
semilogy(find(pvalueAll(:)<=0.05/(16*15)),pvalueAll(pvalueAll<=0.05/(16*15)),'.','Markersize',25,'color',[0.9961,0.3098 ,0.3294])
hold all
plot(0:4:length(pvalueAll(:)), 0.05/(16*15),'k.-')
box off
axis([0 length(pvalueAll(:)) 1e-15 1e0]);
set(gca, 'Xtick',[]);
xlabel('X,Y layer and set type')
ylabel('Hypergeometric test P-value')
set(gca,'Linewidth',2);
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Fig3c.eps
eps2xxx('Fig3c.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');

%% supp
close all
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 19)
figure('Position',[100 100 700 500])
imagesc(k)
c=colorbar;
ylabel(c,'Number of sets');
box on
grid on
ylabels  =  ['S-S';'I-I';'C-C';'M-M';'S-I';'S-C';'S-M';'I-C';'I-M';'C-M';'I-S';'C-I';'C-S';'M-C';'M-I';'M-S'];
set(gca, 'Ytick', 1:16, 'YtickLabel', ylabels)
xlabel('Triad')
xlabels  =  [{'1';'2';'3';'4';'5';'6';'7';'8';'9';'10';'11';'12';'13';'14';'15'}];
set(gca, 'Xtick', 1:15, 'XtickLabel', xlabels, 'LineWidth',2)
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Figsupp5.eps
eps2xxx('Figsupp5.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
