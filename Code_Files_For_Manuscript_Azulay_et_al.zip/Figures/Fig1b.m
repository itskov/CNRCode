
% fig 1b
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
close all;
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 405 300])
foldchange=zeros(1,4);

clf
    slopesstd=zeros(1,4);
    slopesmean=zeros(1,4);
    load('aharonPercentTSecBin.mat')
    temp = polyfit(1:10,aharonPercentT(1:10,3)',1);
    Slope = temp(1); 
    slopesmean(1,1) = Slope;
    X=0:9;
    [f1 e]=fit(X',aharonPercentT(1:10,3),'poly1');
    hold all
load('aharonPercent2SecBin.mat')
Slopes=zeros(1,1500);
    for i=1:1500
    temp = polyfit(1:10,aharonPercent(1:10,4*i - 1)',1);
    Slopes(i) = temp(1);
    end
    
    slopesmean(1,2)=mean(Slopes);
    slopesstd(1,2)=std(Slopes);
avgRandomPercentConnected=mean(aharonPercent(1:10,3:4:6000),2);
stdRandomPercentConnected=std(aharonPercent(1:10,3:4:6000)');
    tem=corrcoef(2:10,avgRandomPercentConnected(2:10)');
    corrmean(1,2) = tem(2,1);
        foldchange(1,2) = (avgRandomPercentConnected(7,1) - avgRandomPercentConnected(2,1)) / avgRandomPercentConnected(2,1);
h1=plot(0:9,aharonPercentT(1:10,3),'.','Color',[0.9961,0.3098 ,0.3294]);

hold all
h2=errorbar(0:9,avgRandomPercentConnected,stdRandomPercentConnected,'.','Color',[0.4863,0.7333,1],'Linewidth',2);
[f2 e]=fit(X',avgRandomPercentConnected,'poly1');
load('aharonPercentPLSecBin.mat')
Slopes=zeros(1,1499);
   for i=1:1499
    temp = polyfit(1:10,aharonPercent(1:10,4*i - 1)',1);
    Slopes(i) = temp(1);
    end
    slopesmean(1,3)=mean(Slopes);
    slopesstd(1,3)=std(Slopes);
avgRandomPercentConnected=mean(aharonPercent(1:10,3:4:5996),2);
stdRandomPercentConnected=std(aharonPercent(1:10,3:4:5996)');    
h3=errorbar(0:9,avgRandomPercentConnected,stdRandomPercentConnected,'.','Color',[0.5765,0.8941,0.3922],'Linewidth',2);
[f3 e]=fit(X',avgRandomPercentConnected,'poly1');
load('aharonPercentERSecBin.mat')
Slopes=zeros(1,1499);
   for i=1:1499
    temp = polyfit(1:10,aharonPercent(1:10,4*i - 1)',1);
    Slopes(i) = temp(1);
    end
    slopesmean(1,4)=mean(Slopes);
    slopesstd(1,4)=std(Slopes);
avgRandomPercentConnected=mean(aharonPercent(1:10,3:4:5996),2);
stdRandomPercentConnected=std(aharonPercent(1:10,3:4:5996)');
stdRandomPercentConnected(1,10) = 8;

h4=errorbar(0:9,avgRandomPercentConnected,stdRandomPercentConnected,'.','Color',[0,0,0],'Linewidth',2);
[f4 e]=fit(X',avgRandomPercentConnected,'poly1');
set(h1,'Marker' , 'o','MarkerSize', 7,'MarkerEdgeColor' , [0.9961,0.3098 ,0.3294],'MarkerFaceColor' , [0.9961,0.3098 ,0.3294]);
set(h2,'Marker' , 'o','MarkerSize', 7,'MarkerEdgeColor' , [0.4863,0.7333,1],'MarkerFaceColor' , [0.4863,0.7333,1]);
set(h3,'Marker' , 'o','MarkerSize', 7,'MarkerEdgeColor' , [0.5765,0.8941,0.3922],'MarkerFaceColor' , [0.5765,0.8941,0.3922]);
set(h4,'Marker' , 'o','MarkerSize', 7,'MarkerEdgeColor' , [0,0,0],'MarkerFaceColor' , [0,0,0]);
xlabel('Number of common neighbors to a given pair');
ylabel('Percent connected');

ylim([0 67]);
xlim([0 10]);
xlabels  =  {'0','1','2','3','4','5','6','7','8','9+'};
set(gca, 'Xtick', 0:9, 'XtickLabel', xlabels)

ff1=plot(f1);
set(ff1,'Color',[0.9961,0.3098 ,0.3294],'LineWidth',2);
ff2=plot(f2);
set(ff2,'Color',[0.4863,0.7333,1],'LineWidth',2);
ff3=plot(f3);
set(ff3,'Color',[0.5765,0.8941,0.3922],'LineWidth',2);
ff4=plot(f4);
set(ff4,'Color',[0,0,0],'LineWidth',2);
box off
set(gca,'LineWidth',2);
hLegend=legend({'\itC. elegans','Shuffled','Power-Law','Erdos-Renyi'});
set(hLegend,'location', 'NorthWest');
legend boxoff
set(gcf, 'Color', 'None')
xlabel('Number of common neighbors to a pair');
ylabel('Percent connected');
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Fig_1b.eps
eps2xxx('Fig_1b.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe')
PVALUE1 = normcdf(-abs((slopesmean(1,1) - slopesmean(1,2)) / slopesstd(1,2)),0,1);
PVALUE2 = normcdf(-abs((slopesmean(1,1) - slopesmean(1,3)) / slopesstd(1,3)),0,1);
PVALUE3 = normcdf(-abs((slopesmean(1,1) - slopesmean(1,4)) / slopesstd(1,4)),0,1);
