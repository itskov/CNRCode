clear all
close all
run_triad10C([0,0,0,0],[0.8, 4, 6]) 
clear all
close all
run_triad10U([0,0,0,0],[0.8, 4, 6])
clear all
close all
run_triad13C([0,0,0,0],[0.8, 4, 5, 6,7]) 
clear all
close all
run_triad13U([0,0,0,0],[0.8, 4, 5, 6,7])
clear all
close all
