load('EnPairs.mat')
load('J2.mat')
load('EJ2.mat')
load('CS2.mat')
load('neuronClass.mat')

TriadsEJ=zeros(2,15);
for i=1:length(EnPairs)
    if (EJ2(EnPairs(1,i),EnPairs(2,i)) && ~CS2(EnPairs(1,i),EnPairs(2,i)) && ~CS2(EnPairs(2,i),EnPairs(1,i)))
        TriadsEJ(1,EnPairs(3,i)) = TriadsEJ(1,EnPairs(3,i)) + 1;
    elseif (~EJ2(EnPairs(1,i),EnPairs(2,i)) && (CS2(EnPairs(1,i),EnPairs(2,i))) || CS2(EnPairs(2,i),EnPairs(1,i)))
        TriadsEJ(2,EnPairs(3,i)) = TriadsEJ(2,EnPairs(3,i)) + 1;
    elseif (EJ2(EnPairs(1,i),EnPairs(2,i)) && (CS2(EnPairs(1,i),EnPairs(2,i))) || CS2(EnPairs(2,i),EnPairs(1,i)))
        TriadsEJ(3,EnPairs(1,i)) = TriadsEJ(1,EnPairs(3,i)) + 1;
        TriadsEJ(3,EnPairs(2,i)) = TriadsEJ(2,EnPairs(3,i)) + 1;

    end
end

%% fig1
close all;
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(4)/2 scrsz(4)/4 scrsz(3)/1.8 scrsz(4)/2.4])
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 20)
B=bar(TriadsEJ(1:2,10:15)','LineWidth',0.1,'BarWidth',1);
set(B(1),'FaceColor',[0.4863,0.7333,1],'EdgeColor',[0.4863,0.7333,1])
set(B(2),'FaceColor',[0.1,0.1,0.1],'EdgeColor',[.1 .1 .1])
ylabel('Number of homogeneous sets');
xlabel('Triad');
legend('Gap junction','Chemical synapse');
legend boxoff
box off
set(gca,'Linewidth',2);
xlabels  =  {'10','11','12','13','14','15'};
set(gca, 'Xtick', 1:6, 'XtickLabel', xlabels)
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Fig3d.eps
eps2xxx('Fig3d.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');

%% fig2
TriadsCSReciprocal=zeros(36,15);
for i=1:length(EnPairs)
    if ((CS2(EnPairs(1,i),EnPairs(2,i))) && CS2(EnPairs(2,i),EnPairs(1,i)))
        disp('s');
        if (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(1,EnPairs(3,i)) = TriadsCSReciprocal(1,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(2,EnPairs(3,i)) = TriadsCSReciprocal(2,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(3,EnPairs(3,i)) = TriadsCSReciprocal(3,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(4,EnPairs(3,i)) = TriadsCSReciprocal(4,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(5,EnPairs(3,i)) = TriadsCSReciprocal(5,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(6,EnPairs(3,i)) = TriadsCSReciprocal(6,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(7,EnPairs(3,i)) = TriadsCSReciprocal(7,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(8,EnPairs(3,i)) = TriadsCSReciprocal(8,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(9,EnPairs(3,i)) = TriadsCSReciprocal(9,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(10,EnPairs(3,i)) = TriadsCSReciprocal(10,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 1 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(11,EnPairs(3,i)) = TriadsCSReciprocal(11,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(12,EnPairs(3,i)) = TriadsCSReciprocal(12,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(13,EnPairs(3,i)) = TriadsCSReciprocal(13,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(14,EnPairs(3,i)) = TriadsCSReciprocal(14,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(15,EnPairs(3,i)) = TriadsCSReciprocal(15,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 2 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(16,EnPairs(3,i)) = TriadsCSReciprocal(16,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(17,EnPairs(3,i)) = TriadsCSReciprocal(17,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(18,EnPairs(3,i)) = TriadsCSReciprocal(18,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(19,EnPairs(3,i)) = TriadsCSReciprocal(19,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(20,EnPairs(3,i)) = TriadsCSReciprocal(20,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 3 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(21,EnPairs(3,i)) = TriadsCSReciprocal(21,EnPairs(3,i)) + 1;
         elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(22,EnPairs(3,i)) = TriadsCSReciprocal(22,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(23,EnPairs(3,i)) = TriadsCSReciprocal(23,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(24,EnPairs(3,i)) = TriadsCSReciprocal(24,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(25,EnPairs(3,i)) = TriadsCSReciprocal(25,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 4 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(26,EnPairs(3,i)) = TriadsCSReciprocal(26,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(27,EnPairs(3,i)) = TriadsCSReciprocal(27,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(28,EnPairs(3,i)) = TriadsCSReciprocal(28,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(29,EnPairs(3,i)) = TriadsCSReciprocal(29,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(30,EnPairs(3,i)) = TriadsCSReciprocal(30,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 5 && neuronClass(EnPairs(2,i),2) == 6)
            TriadsCSReciprocal(31,EnPairs(3,i)) = TriadsCSReciprocal(31,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 1)
            TriadsCSReciprocal(32,EnPairs(3,i)) = TriadsCSReciprocal(32,EnPairs(3,i)) + 1; 
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 2)
            TriadsCSReciprocal(33,EnPairs(3,i)) = TriadsCSReciprocal(33,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 3)
            TriadsCSReciprocal(34,EnPairs(3,i)) = TriadsCSReciprocal(34,EnPairs(3,i)) + 1;
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 4)
            TriadsCSReciprocal(35,EnPairs(3,i)) = TriadsCSReciprocal(35,EnPairs(3,i)) + 1;            
        elseif (neuronClass(EnPairs(1,i),2) == 6 && neuronClass(EnPairs(2,i),2) == 5)
            TriadsCSReciprocal(36,EnPairs(3,i)) = TriadsCSReciprocal(36,EnPairs(3,i)) + 1;            
        else
            disp('sss');
        end
    end
end
