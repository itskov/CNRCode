load('RandomNetworksMatrix2.mat');
J=RandomNetworksMatrix2(:,:,1501);
clearvars NeuronType;
[PO,OP,NeuronType] = xlsread('NeuronType.xls');
clearvars OP PO;
NeuronType(1,:) = [];
dist=zeros(280,280);
for i=1:length(1:280)
    for j=1:length(1:280)
        if (NeuronType{i,2} >= NeuronType{j,2} && ~isequal(NeuronType{i,1},'NMJ') && ~isequal(NeuronType{j,1},'NMJ'))
            dist(i,j) = NeuronType{i,2}-NeuronType{j,2};
        elseif (NeuronType{i,2} < NeuronType{j,2} && ~isequal(NeuronType{i,1},'NMJ') && ~isequal(NeuronType{j,1},'NMJ'))
            dist(i,j) = NeuronType{j,2}-NeuronType{i,2};
        end
    end
end
dist(:) = dist(:) *100;
dist(:) = str2num(num2str(dist(:)));
dist(:) = dist(:) / 100;
NumOfDist=sort(unique(dist(:)));
aharonTP=zeros(length(unique(NumOfDist)),2);
aharonPercentTP=zeros(size(aharonTP,1),size(aharonTP,2));

for i=1:280
    for j=1:280
        lala = find(NumOfDist == dist(i,j));
        if (i<j && J(i,j) > 0 && J(j,i) > 0)
            aharonTP(lala,1) = aharonTP(lala,1) + 1;
        elseif (i~=j && xor(J(i,j),J(j,i)))
            aharonTP(lala,1) = aharonTP(lala,1) + 1;
        elseif (i~=j && J(i,j) ==0 && J(j,i) == 0)
            aharonTP(lala,2) = aharonTP(lala,2) + 1;
        end
    end
end

for i=1:size(aharonTP,1)
aharonPercentTP(i,1) = (aharonTP(i,1) / (aharonTP(i,1) + aharonTP(i,2)));
aharonPercentTP(i,2) = (aharonTP(i,2) / (aharonTP(i,1) + aharonTP(i,2)));
end


D=NumOfDist;
E=aharonPercentTP(:,1);
E(isnan(E)) = 0 ;
cnt = aharonTP(:,1);
arr=[1,2,4,8,16,32,64,128,256,512,1028];
for i=arr;
    te=(cnt>j);
    te2 = cnt<(i+1);
    te3 = te .* te2;
    te3 = te3>0;
cnt(te3) = find(arr==i);
j=i;
end
close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
figure('Position',[100 100 565 300])
hh=scatter(D, E, 170, cnt,'.');
axis([0 0.8 0 0.14]);
map = [0, 0, 0.0
    0.1, 0.1, 0.2
    0.2, 0.2, 0.5
    0.3,0.3,0.6
    0.3,0.4,0.5
    0.3,0.8,0.3
    0.4,0.6,0.3
    0.6,0.4,0.3
    0.8,0.2,0.2];
colormap(map);



c=colorbar;
xlabel('Normalized distance between a pair');
ylabel({'Fraction of' ,'connected pairs'});
ylabel(c,{'# connected pairs (log2)'})
set(gca,'Linewidth',2);

    set(gcf, 'PaperPositionMode', 'auto');
    print -depsc2 Figsupp2.eps
    eps2xxx('Figsupp2.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
