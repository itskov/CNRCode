
Aje=CreateMat( 'Facebook_user1.xlsx');
aharonT=zeros(100,4*101);
aharonPercentT=zeros(size(aharonT,1),size(aharonT,2));
for c=100:101;      
    c
duoCN=[1 2 3 4 5 6 7 8 9 10*ones(1,91)];
J=FacebookRandMat(:,:,c);
con=zeros(length(J));
con2=zeros(length(J));
for i=1:length(J)
    temp=find(J(:,i));
    temp2=find(J(i,:));
    if (numel(temp) ~=0)
    con(i,1:length(temp)) = temp;
    end
    if (numel(temp2) ~=0)
    con2(i,1:length(temp2)) = temp2;
    end
end

yesorno = J~=0;

connec=cell(1,3);
e=1;
t=1;
row=1;
pairs=[];
for i=1:length(con)
for j=1:length(con)
     Q=intersect(con(i,:),con(j,:)); 
     W=intersect(con2(i,:),con2(j,:));
     E=intersect(con(i,:),con2(j,:));
     R=intersect(con2(i,:),con(j,:));
     QWER=[Q W E R];
     QWER=unique(QWER);
     QWER(QWER==0) = [];
       if ((yesorno(i,j) == 1 && yesorno(j,i) == 1 && i<j))
       aharonT(duoCN(length(QWER) + 1),4*c - 3) = aharonT(duoCN(length(QWER) + 1),4*c - 3)  + 1;
       if (length(QWER) == 1)
           
       pairs(row,:)= [i j];
       row=row+1;
       end
      elseif (yesorno(i,j) == 1 && yesorno(j,i) == 0 && i~=j)
       aharonT(duoCN(length(QWER) + 1),4*c - 2) = aharonT(duoCN(length(QWER) + 1),4*c - 2)  + 1;
       if (length(QWER) == 1)
       pairs(row,:)= [i j];
       row=row+1;
       end
      elseif (yesorno(i,j) == 0 && yesorno(j,i) == 0 && i<j)
       aharonT(duoCN(length(QWER) + 1),4*c) = aharonT(duoCN(length(QWER) + 1),4*c)  + 1;
       end

end
end
aharonT(:,4*c - 1) = aharonT(:,4*c - 3) + aharonT(:,4*c - 2);


for i=1:size(aharonT,1)
aharonPercentT(i,4*c - 3) = (aharonT(i,4*c - 3) / (aharonT(i,4*c) + aharonT(i,4*c - 3) + aharonT(i,4*c - 2))) * 100;
aharonPercentT(i,4*c - 2) = (aharonT(i,4*c - 2) / (aharonT(i,4*c) + aharonT(i,4*c - 3) + aharonT(i,4*c - 2))) * 100;
aharonPercentT(i,4*c - 1) = (aharonT(i,4*c - 1) / (aharonT(i,4*c) + aharonT(i,4*c - 3) + aharonT(i,4*c - 2))) * 100;
aharonPercentT(i,4*c) = (aharonT(i,4*c) / (aharonT(i,4*c) + aharonT(i,4*c - 3) + aharonT(i,4*c - 2))) * 100;
end
save('aharonPercentFacebook','aharonPercentT');
end
