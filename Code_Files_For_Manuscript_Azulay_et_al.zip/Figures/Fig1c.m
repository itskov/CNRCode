clear all
close all
load('RandomNetworksMatrix2.mat')

J=RandomNetworksMatrix2(:,:,1501);

con=zeros(length(J));
con2=zeros(length(J));
for i=1:length(J)
    temp=find(J(:,i));
    temp2=find(J(i,:));
    if (numel(temp) ~=0)
    con(i,1:length(temp)) = temp;
    end
    if (numel(temp2) ~=0)
    con2(i,1:length(temp2)) = temp2;
    end
end
degree=zeros(280,1);
for i=1:280
    TEMP = [con(i,:) con2(i,:)];
    TEMP(TEMP==0) = [];
    degree(i) = length(unique(TEMP));
end

degree2=zeros(280,1);
degree3=zeros(280,1);
degree2 = tiedrank(degree) / length(degree);

yesorno = J~=0;

connec=cell(1,3);
e=1;
t=1;
for i=1:length(con)
for j=1:length(con)
    Q=intersect(con(i,:),con(j,:)); 
     W=intersect(con2(i,:),con2(j,:));
     E=intersect(con(i,:),con2(j,:));
     R=intersect(con2(i,:),con(j,:));
     QWER=[Q W E R];
     QWER=unique(QWER);
     QWER(QWER==0) = [];
if ((yesorno(i,j) == 1 && yesorno(j,i) == 1) || ((yesorno(i,j) == 1 || yesorno(j,i) == 1)) && i~=j)
     Q=intersect(con(i,:),con(j,:)); 
     W=intersect(con2(i,:),con2(j,:));
     E=intersect(con(i,:),con2(j,:));
     R=intersect(con2(i,:),con(j,:));
     QWER=[Q W E R];
     QWER=unique(QWER);
     QWER(QWER==0) = [];
     if ((yesorno(i,j) == 1 && yesorno(j,i) == 1))
CNmax(i,j) = length(QWER);
CNmax(j,i) = length(QWER);
CNmaxC(i,j) = length(QWER);
CNmaxC(j,i) = length(QWER);
     elseif((yesorno(i,j) == 1 || yesorno(j,i) == 1) && i~=j)
CNmax(i,j) = length(QWER);
CNmaxC(i,j) = length(QWER);
     end

end
if (yesorno(i,j) == 0  && i~=j)
     Q=intersect(con(i,:),con(j,:)); 
     W=intersect(con2(i,:),con2(j,:));
     E=intersect(con(i,:),con2(j,:));
     R=intersect(con2(i,:),con(j,:));
     QWER=[Q W E R];
     QWER=unique(QWER);
     QWER(QWER==0) = [];
%      CNmax(i,j) = length(QWER);
%      CNmaxD(i,j) = length(QWER);
end
end
end



%DISTANCE VS NUMCOMMONNEIGHBORS
clearvars NeuronType;
[PO,OP,NeuronType] = xlsread('NeuronType.xls');
clearvars OP PO;
NeuronType(1,:) = [];

dist=zeros(280,280);
for i=1:length(1:280)
    for j=1:length(1:280)
        if (NeuronType{i,2} >= NeuronType{j,2} && ~isequal(NeuronType{i,1},'NMJ') && ~isequal(NeuronType{j,1},'NMJ'))
            dist(i,j) = NeuronType{i,2}-NeuronType{j,2};
        elseif (NeuronType{i,2} < NeuronType{j,2} && ~isequal(NeuronType{i,1},'NMJ') && ~isequal(NeuronType{j,1},'NMJ'))
            dist(i,j) = NeuronType{j,2}-NeuronType{i,2};
        end
    end
end
dist(:) = dist(:) *100;
dist(:) = str2num(num2str(dist(:)));
dist(:) = dist(:) / 100;

for i=1:280
    for j=1:280
        if (i>=j)
            dist(i,j)= -1;
            CNmax(i,j)= -1;
        end
    end
end
        
D=dist(:);
E=CNmax(:);
D(D==-1) = [];
E(E==-1) = [];


A=[D E];
[Auniq,~,IC] = unique(A,'rows');
cnt = accumarray(IC,1);
arr=[1,2,4,8,16,32,64,128,256,512,1028,2056];

count=0;
for i=1:length(A)
    if (A(i,1) == 0 && A(i,2) == 0)
        count=count+1;
    end
end

%% fig
close all;
set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)
figure('Position',[100 100 565 300])
hh=scatter(Auniq(:,1), Auniq(:,2), 13, cnt,'o','filled');
axis([0 0.8 0 43]);
colormap(jet(max(cnt)));
map = [0.0, 0.0, 0.0
    0.0, 0.0, 0.6
    0,0,1
    0,0.6,0.6
    0,1,1
    0.6,0.6,0
    1,1,0
    0,0.6,0
    0.0,1,0.0
    0.6,0,0.6
    1,0,1
    0.6,0,0
    1,0,0];
colormap(map);



            
c=colorbar;
set(c,'box','off');
xlabel('Normalized distance between a pair');
ylabel({'Number of common' ,'neighbors to a pair'});
ylabel(c,{'Number of pairs'})
set(gca,'Linewidth',2);
    set(gcf, 'PaperPositionMode', 'auto');
    print -depsc2 Fig1c.eps
    eps2xxx('Fig1c.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe');
   close all
   
