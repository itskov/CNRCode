set(0,'DefaultAxesFontName', 'Helvetica')
set(0,'DefaultAxesFontSize', 16)

load('aharonPercentFacebook.mat')
h1=plot(0:8,aharonPercentT(1:9,403),'o');
set(h1,'Marker' , 'o','MarkerSize', 8,'MarkerEdgeColor' , [0.5,0.5,1],'MarkerFaceColor' , [0.5,0.5,1]);

 hold all
X=0:8;
    %sup fig 1a
    [f e]=fit(X',aharonPercentT(1:9,403),'poly1');
    ff=plot(f);
set(ff,'Color',[0.5,0.5,0.5],'LineWidth',2);
xlabel('Number of common friends to a given pair');
ylabel('Percent connected');
ylim([0 40]);
lege=legend({'Facebook','Linear fit'},'Location','northwest');
xlabels  =  {'0','1','2','3','4','5','6','7','8+'};
box off
legend boxoff
set(gca, 'Xtick', 0:8, 'XtickLabel', xlabels, 'LineWidth',2)
set(gcf, 'PaperPositionMode', 'auto');
print -depsc2 Figsupp7.eps
eps2xxx('Figsupp7.eps',{'pdf'},'C:\Program Files\gs\gs9.15\bin\gswin64.exe')