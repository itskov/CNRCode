function [ J ] = ERCreateNetworks(  )
%POWERLAWCREATENETWORKS Summary of this function goes here
%   Detailed explanation goes here
n=280;
J=zeros(n,n);
for i = 1:n
    currentDegree = randsample(5:15,1,true);
    ivector= 1:n;
    ivector(ivector==i) = [];
    J(i,randsample(ivector,currentDegree,false)) = 1;
    outDegree = sum(J,1);
    inDegree = sum(J,2);
% degrees=randsample(1:n,n, true, (1:n).^(-lambda));
% degrees = sort(degrees,'descend');
end
end


for i=1:280
    for j=1:280
        if(i~=j)
       J(i,j) = randsample([0 1],1,true,[0.965 0.035]);
        end
    end
end
sum(sum(J))
        
