function [ J ] = randomNetworkNew(JJ,k)
%RANDOMNET Returns randomized network based on c.elegans network degree
    t1=clock;
    s=0;
    A=1;
    B=1;
    C=1;
    D=1;
    for n=1:k
            J(:,:,n) = JJ;
        emek1 = 0;
        emek2 = 0;
        for i=1:5000
        EnterWhileLoop=1;
        while (sum(J(A,:,n)) == 0 || sum(J(B,:,n)) == 0 || EnterWhileLoop == 1)
        A=randsample(280,1);
        B=randsample(280,1);
        EnterWhileLoop=0;
        end
        EnterWhileLoop2=1;
        counter=0;
        while ((C==D || EnterWhileLoop2==1 || ~((J(C,A,n) > 0 && J(D,B,n) > 0) || (J(C,A,n) == 0 && J(D,B,n) == 0))) && counter<20)
        C=randsample(find(J(A,:,n)~=0),1);
        D=randsample(find(J(B,:,n)~=0),1);
        EnterWhileLoop2=0;
        counter=counter+1;
        end
        if (counter<5)
        if (J(A,D,n) == 0 && J(B,C,n) == 0 && A~=D && B~=C && A~=C && B~=D)
            if (J(C,A,n) == 0 && J(D,B,n) == 0 && J(D,A,n) == 0 && J(C,B,n) == 0)
          s=sum(sum((J(:,:,n))));
        a=J(B,D,n);
        b=J(A,C,n);
        J(A,C,n) = 0;
        J(A,D,n) = b;
        J(B,D,n) = 0;
        J(B,C,n) = a;
        if (sum(sum((J(:,:,n)))) ~= s)
            echo
        end
            elseif (J(C,A,n) > 0 && J(D,B,n) > 0 && J(D,A,n) == 0 && J(C,B,n) == 0)
                s=sum(sum(J(:,:,n)));
        a=J(B,D,n);
        b=J(A,C,n);
        c=J(D,B,n);
        d=J(C,A,n);
        J(A,C,n) = 0;
        J(C,A,n) = 0;
        J(B,D,n) = 0;
        J(D,B,n) = 0;
        J(A,D,n) = b;
        J(D,A,n) = d;
        J(C,B,n) = c;
        J(B,C,n) = a;
              if (sum(sum((J(:,:,n)))) ~= s)
            echo
        end
            end
        else
            emek2 = emek2 + 1; 
        end
        else
            emek1 = emek1 + 1;
        end
        end
    end
    t2=clock;
    disp([num2str(etime(t2,t1)) ' seconds']);
end