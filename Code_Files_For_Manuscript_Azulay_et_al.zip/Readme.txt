Figures: The code for generating all the figures is located in the folder "Figures" in .m files. For example, fig3d.m is the script for generating Fig 3d.

RandomNetworks: The functions for generating the three types of random networks that we used in the paper are located in the folder "RandomNetworks".

Homogeneous Sets Finder: This function take a directed adjacency matrix (of a neural networks), and returns all the homogeneous sets. 